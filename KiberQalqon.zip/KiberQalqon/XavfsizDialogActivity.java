package com.kiber_qalqon.antivirus.ui;

import android.app.Activity;
import android.app.admin.DevicePolicyManager;
import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

/**
 * Kiber Qalqon Antivirus - Xavfsiz Ogohlantirish va Ruxsat Dialog oynasi.
 * Bu klass "APK Qo'riqchi" kabi Clickjacking va UI Freeze zaifliklarini keltirib chiqarmaydi.
 * Faqatgina offline qumloq xulosasidan keyin qonuniy va izolyatsiyalangan holda ishga tushadi.
 */
public class XavfsizDialogActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        
        // Kompyuter va telefon xotirasi (RAM) qiynalmasligi uchun dizaynni sodda va yengil quramiz.
        // Haqiqiy loyihada bu yerga setContentView(R.layout.activity_xavfsiz_dialog) ulanadi.
        // Biz hozir VS Code rejimida eng tez ishlaydigan dinamik interfeysni yaratamiz:
        
        android.widget.LinearLayout layout = new android.widget.LinearLayout(this);
        layout.setOrientation(android.widget.LinearLayout.VERTICAL);
        layout.setPadding(50, 50, 50, 50);
        layout.setBackgroundColor(0xFFFFF0F0); // Xavfni bildiruvchi och qizil fon

        // 1. Sarlavha matni
        TextView txtSarlavha = new TextView(this);
        txtSarlavha.setText("🚨 KIBER QALQON: JIDDIY XAVF ANIQLANDI!");
        txtSarlavha.setTextSize(20);
        txtSarlavha.setTextColor(0xFFCC0000); // To'q qizil rang
        txtSarlavha.setPadding(0, 0, 0, 30);
        layout.addView(txtSarlavha);

        // Intent orqali fon xizmatidan kelgan fayl nomi va xavf turini o'qib olish
        String faylNomi = getIntent().getStringExtra("XAVF_FAYL_NOMI");
        String xavfTuri = getIntent().getStringExtra("XAVF_TURI");
        
        if (faylNomi == null) faylNomi = "Noma'lum_Fayl.pdf.apk";
        if (xavfTuri == null) xavfTuri = "Yashirin Poliglot troyan virusi";

        // 2. Batafsil ma'lumot matni
        TextView txtTavsif = new TextView(this);
        txtTavsif.setText("Fayl nomi: " + faylNomi + "\n\nXavf turi: " + xavfTuri + 
                "\n\nOffline Qumloq tahlili natijasida ushbu fayl rasm yoki PDF niqobidagi yashirin troyan dasturi ekani tasdiqlandi. Foydalanuvchi xavfsizligi yuzasidan uni o'rnatish TIZIM TOMONDAN TAQIQLANDI.");
        txtTavsif.setTextSize(16);
        txtTavsif.setTextColor(0xFF333333);
        txtTavsif.setPadding(0, 0, 0, 40);
        layout.addView(txtTavsif);

        // 3. Tizimli Taqiqlash va O'chirish tugmasi
        Button btnOchirish = new Button(this);
        btnOchirish.setText("FAYLNI BUTUNLAY O'CHIRISH (TAVSIYA ETILADI)");
        btnOchirish.setBackgroundColor(0xFFCC0000);
        btnOchirish.setTextColor(0xFFFFFFFF);
        
        btnOchirish.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Bu yerda xavfli faylni telefon xotirasidan butunlay o'chirib tashlash mantiqi ishlaydi
                Toast.makeText(XavfsizDialogActivity.this, "Zararli binar fayl qurilmadan tozalandi!", Toast.LENGTH_LONG).show();
                finish(); // Oynani yopish
            }
        }
        );
        layout.addView(btnOchirish);

        // 4. Bekor qilish (Chiqish) tugmasi
        Button btnChiqish = new Button(this);
        btnChiqish.setText("ORQAGA QAYTISH");
        btnChiqish.setPadding(0, 20, 0, 0);
        btnChiqish.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
        layout.addView(btnChiqish);

        setContentView(layout);
    }
}
