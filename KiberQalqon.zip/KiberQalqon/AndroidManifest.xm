<?xml version="1.0" encoding="utf-8"?>
<manifest xmlns:android="http://android.com"
    package="com.kiber_qalqon.antivirus"
    android:versionCode="1"
    android:versionName="1.0.0">

    <!-- Fonda real vaqtda himoya xizmatini yuritish huquqi -->
    <uses-permission android:name="android.permission.FOREGROUND_SERVICE"/>
    <!-- Telefonga o'rnatilayotgan barcha paketlarni dynamic tahlil qilish huquqi -->
    <uses-permission android:name="android.permission.QUERY_ALL_PACKAGES"/>

    <application
        android:allowBackup="false"
        android:label="Kiber Qalqon Antivirus"
        android:supportsRtl="true"
        android:theme="@style/Theme.AppCompat.Light.NoActionBar">

        <!-- ASOSIY INTERFEYS: Faqat foydalanuvchiga ma'lumot ko'rsatuvchi yuzaki oyna -->
        <activity
            android:name=".ui.MainActivity"
            android:exported="true"
            android:launchMode="singleTop">
            <intent-filter>
                <action android:name="android.intent.action.MAIN"/>
                <category android:name="android.intent.category.LAUNCHER"/>
            </intent-filter>
        </activity>

        <!-- XAVFSIZ OGOHLANTIRISH OYNASI: Clickjacking xavfidan xoli, qonuniy taqiq dialogi -->
        <activity
            android:name=".ui.XavfsizDialogActivity"
            android:exported="false"
            android:theme="@style/Theme.AppCompat.DayNight.Dialog"
            android:excludeFromRecents="true"/>

        <!-- FON XIZMATI: PackageInstaller sessiyalarini va Telegram fayllarini poylovchi xizmat -->
        <service
            android:name=".service.HimoyaForegroundService"
            android:enabled="true"
            android:exported="false"/>

        <!-- 🔒 OFFLINE QUMLOQ (OFFLINE SANDBOX): Mutloq izolyatsiya qilingan jarayon. 
             Internet huquqi yo'q, Linux Kernel darajasida qulflangan, qochib bo'lmaydigan muhit -->
        <service
            android:name=".sandbox.OfflineSandboxService"
            android:enabled="true"
            android:exported="false"
            android:isolatedProcess="true" 
            android:process=":isolated_sandbox"/>

        <!-- QURILMA ADMINISTRATORI: Noma'lum manbalardan APK o'rnatishni poydevorida bloklovchi huquq -->
        <receiver
            android:name=".receiver.KiberAdminReceiver"
            android:permission="android.permission.BIND_DEVICE_ADMIN"
            android:exported="true">
            <meta-data
                android:name="android.app.device_admin"
                android:resource="@xml/device_admin_rules"/>
            <intent-filter>
                <action android:name="android.app.action.DEVICE_ADMIN_ENABLED"/>
            </intent-filter>
        </receiver>

    </application>
</manifest>
