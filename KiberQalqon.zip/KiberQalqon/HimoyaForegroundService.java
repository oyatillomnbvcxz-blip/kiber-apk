package com.kiber_qalqon.antivirus.service;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.IBinder;
import androidx.core.app.NotificationCompat;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

/**
 * Kiber Qalqon Antivirus - Chaqmoq tezligidagi fon tahlil xizmati.
 * Bu xizmat "APK Qo'riqchi" kabi ekranni poylab telefonni qotirmaydi.
 * Fayllarni binar sarlavhasi (Magic Bytes) orqali 0.1 soniyada offline saralaydi.
 */
public class HimoyaForegroundService extends Service {

    private static final String CHANNEL_ID = "KiberQalqonChannel";
    private static final int NOTIFICATION_ID = 101;

    @Override
    public void onCreate() {
        super.onCreate();
        createNotificationChannel();
        Notification notification = new NotificationCompat.Builder(this, CHANNEL_ID)
                .setContentTitle("Kiber Qalqon Himoyasi Faol")
                .setContentText("Real vaqt rejimida Telegram va fayllar nazorat qilinmoqda...")
                .setSmallIcon(android.R.drawable.ic_secure)
                .build();
        
        // Xizmatni Foreground (Fonda o'chmaydigan) rejimda ishga tushirish
        startForeground(NOTIFICATION_ID, notification);
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        // Bu yerda dynamic tahlil jarayoni boshlanadi
        if (intent != null && intent.hasExtra("FAYL_YO'LI")) {
            String faylYoli = intent.getStringExtra("FAYL_YO'LI");
            
            // Kompyuter va telefon RAM xotirasi qiynalmasligi uchun parallel oqimda tekshiramiz
            new Thread(() -> {
                tekshirFaylBinar(faylYoli);
            }).start();
        }
        return START_STICKY;
    }

    /**
     * 🔍 Magic Bytes (Sehrli baytlar) orqali feyk hujjatlarni fosh qilish algoritmi.
     * Foydalanuvchi PDF deb o'ylagan fayl aslida APK (Zip) ekanini 0.1 soniyada aniqlaydi.
     */
    private void tekshirFaylBinar(String faylYoli) {
        File fayl = new File(faylYoli);
        if (!fayl.exists()) return;

        try (FileInputStream fis = new FileInputStream(fayl)) {
            byte[] sarlavha = new byte[4];
            int oqilganBayt = fis.read(sarlavha);

            if (oqilganBayt >= 2) {
                // 1. Agar fayl binar darajada 'P' va 'K' (0x50, 0x4B) bilan boshlansa - bu ZIP/APK arxivdir!
                if (sarlavha[0] == 0x50 && sarlavha[1] == 0x4B) {
                    // Feyk tekshiruv: Agar nomi .pdf bo'lsa-yu, ichi APK bo'lsa - bu xakerlik tuzog'i!
                    if (fayl.getName().toLowerCase().endsWith(".pdf") || fayl.getName().toLowerCase().endsWith(".jpg")) {
                        boshlaTaqiqlashMexanizmi(fayl.getName(), "Feyk Hujjat Tuzog'i (Poliglot APK)");
                        return;
                    }
                }
                
                // 2. Haqiqiy PDF tekshiruvi: Agar fayl '%PDF' (0x25, 0x50, 0x44, 0x46) bilan boshlansa
                if (sarlavha[0] == 0x25 && sarlavha[1] == 0x50 && sarlavha[2] == 0x44 && sarlavha[3] == 0x46) {
                    // Fayl toza PDF hujjat, xavfsiz va tezkorlik bilan o'tkazib yuboriladi
                    System.out.println("Kiber Qalqon: Toza hujjat aniqlandi. Ruxsat berildi.");
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void boshlaTaqiqlashMexanizmi(String faylNomi, String xavfTuri) {
        // Xavf aniqlanganda Clickjacking'dan xoli bo'lgan Xavfsiz Dialog oynasini ochish
        Intent dialogIntent = new Intent(this, com.pairip.application.Application.class); // Bu yerga keyingi dialog klassi ulanadi
        dialogIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_EXCLUDE_FROM_RECENTS);
        dialogIntent.putExtra("XAVF_FAYL_NOMI", faylNomi);
        dialogIntent.putExtra("XAVF_TURI", xavfTuri);
        // Tizimli taqiq oynasini ishga tushirish
        // startActivity(dialogIntent); 
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel serviceChannel = new NotificationChannel(
                    CHANNEL_ID,
                    "Kiber Qalqon Fon Xizmati",
                    NotificationManager.IMPORTANCE_LOW
            );
            NotificationManager manager = getSystemService(NotificationManager.class);
            if (manager != null) {
                manager.createNotificationChannel(serviceChannel);
            }
        }
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}
